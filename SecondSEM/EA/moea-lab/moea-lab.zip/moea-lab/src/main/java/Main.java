import org.moeaframework.Executor;


public class Main {


    public static void ex1() {
        Executor executor = new Executor();
    }

    public static void ex2() {

    }

    public static void ex3() {

    }

    public static void ex4() {

    }

    public static void main(String[] args) {
        System.out.println("Hello MOEA!");
        ex1();
        ex2();
        ex3();
        ex4();
    }

}
