All movies will be saved in this folder by default
