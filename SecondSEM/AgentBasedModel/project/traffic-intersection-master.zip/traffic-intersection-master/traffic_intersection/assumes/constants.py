import assumes.params
g = 9.81 * params.pixel_to_meter_scale_factor
