# Test Assignment

1. Fork this project
2. Add @mateusz.slazynski as the new project's member (role: ``master``)
3. Check the ``handout.pdf`` for the instructions. Ignore all sections about submitting to coursera.
4. Solve the problem!
5. If done before the deadline, contact @mateusz.slazynski via Slack, so he can check it earlier.